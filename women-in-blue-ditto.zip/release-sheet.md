# Women in Blue: Ditto release sheet

Upload at ditto.music (Upload Music), as a single.

| Field | Fill in |
|---|---|
| Release type | Single |
| Release title | Women in Blue |
| Track title | Women in Blue |
| Primary artist | ÆTHER (pick the same ÆTHER profile you used before, or create it as a new artist; other "Aether" artists exist) |
| Featured artist | leave empty |
| Songwriter / composer | Jithesh Menon (your legal name) |
| Lyricist | Jithesh Menon |
| Producer | ÆTHER |
| Label | ÆTHER (or leave as Independent) |
| Genre | Pop (secondary: Electronic / Dance) |
| Language of lyrics | English |
| Explicit | No |
| Audio file | 01-women-in-blue.wav (WAV, 16-bit, 44.1 kHz, 3:00) |
| Cover art | women-in-blue-cover.jpg (3000x3000 JPG) |
| Lyrics | paste lyrics.txt |
| AI-generated | Yes (music made with an AI music tool; lyrics written by you) |
| AI training program | Do NOT opt in |
| YouTube Content ID | Do NOT opt in (our own ÆTHER videos use this track) |
| ISRC / UPC | leave empty, Ditto gives them free |
| Release date | at least 7 days ahead gives the best chance of Spotify editorial pitch; earliest is 1-3 days |
| Copyright line | 2026 ÆTHER |
| Previously released | No (YouTube videos don't count as a release) |

Notes
- The cover has no player photos, no team logo and no BCCI mark on purpose: stores reject covers with people or brands we don't own the rights to.
- Don't put "India", "Team India" or player names in the title or artist fields; it's a fan song, and stores reject misleading artist metadata.
- The track must be from your paid ElevenLabs plan for streaming rights (free-plan songs can't be distributed).
- Ditto Starter is $19/yr after the free trial. Tell me the trial end date and I'll remind you before it charges.
- When it's live, send me the Spotify link and I'll add it to the 4 Women in Blue videos.
